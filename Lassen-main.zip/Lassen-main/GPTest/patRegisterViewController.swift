//
//  patRegisterViewController.swift
//  GPTest
//
//  Created by Aljoharah . on 25/01/2021.
//

import UIKit

class patRegisterViewController: UIViewController {

    @IBOutlet weak var regButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        regButton.applyButtonDesign()
    }
    

    @IBOutlet weak var phone: UILabel!
    

}


