//
//  FormsViewController.swift
//  GPTest
//
//  Created by Mada saad on 02/02/2021.
//

import UIKit

class FormsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var Form: UIButton!
    @IBAction func Form(_ sender: Any) {
    }
    @IBOutlet weak var quest: UIButton!
    @IBAction func quest(_ sender: Any) {
    }
           
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
