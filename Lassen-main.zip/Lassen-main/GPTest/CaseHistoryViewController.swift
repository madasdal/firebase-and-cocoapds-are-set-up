//
//  CaseHistoryViewController.swift
//  GPTest
//
//  Created by Mada saad on 02/02/2021.
//

import UIKit

class CaseHistoryViewController: UIViewController {
   @IBOutlet weak var SAVE: UIButton!
    @IBOutlet weak var save: UIButton!
    override func viewDidLoad() {
                  super.viewDidLoad()

                  SAVE.applyButtonDesign()
              }
              
   
     @IBAction func save(_ sender: Any) {
     }
     /*   /*
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
 
}
 }
 }
